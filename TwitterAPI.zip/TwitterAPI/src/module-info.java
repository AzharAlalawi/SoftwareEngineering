module TwitterAPI {
	requires org.twitter4j.core;
}